# Notice

Work is in progress to convert the legacy Visual Paradigm 12 models to draw.io format. Updating the `xroad_analysis.vpp` and `xroad_architecture.vpp` is prohibited and all changes need to be done in draw.io (https://draw.io) format.

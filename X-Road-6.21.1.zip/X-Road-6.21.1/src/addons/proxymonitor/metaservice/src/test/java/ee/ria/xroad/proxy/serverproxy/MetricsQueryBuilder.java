/**
 * The MIT License
 * Copyright (c) 2018 Estonian Information System Authority (RIA),
 * Nordic Institute for Interoperability Solutions (NIIS), Population Register Centre (VRK)
 * Copyright (c) 2015-2017 Estonian Information System Authority (RIA), Population Register Centre (VRK)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package ee.ria.xroad.proxy.serverproxy;

import ee.ria.xroad.common.message.SoapBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.soap.SOAPBody;

import java.util.List;

/**
 * Utility for building getSecurityServerMetrics node with listed content.
 */
public class MetricsQueryBuilder implements SoapBuilder.SoapBodyCallback {

    public static final String NS_MONITORING = "http://x-road.eu/xsd/monitoring";

    List<String> metricNames;

    public MetricsQueryBuilder(List<String> metricNames) {
        this.metricNames = metricNames;
    }

    @Override
    public void create(SOAPBody soapBody) throws Exception {

        Document doc = soapBody.getOwnerDocument();
        Element metricsNode = doc.createElementNS(NS_MONITORING, "getSecurityServerMetrics");
        soapBody.appendChild(metricsNode);

        Element outputSpecNode = doc.createElementNS(NS_MONITORING, "outputSpec");
        metricsNode.appendChild(outputSpecNode);

        for (String metricName : metricNames) {
            Element outputFieldNode1 = doc.createElementNS(NS_MONITORING, "outputField");
            outputFieldNode1.setTextContent(metricName);
            outputSpecNode.appendChild(outputFieldNode1);
        }
    }

}

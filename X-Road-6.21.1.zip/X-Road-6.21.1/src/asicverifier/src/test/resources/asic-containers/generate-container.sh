
cd $1; zip -r $1.asice *; mv $1.asice ../..; cd ..
